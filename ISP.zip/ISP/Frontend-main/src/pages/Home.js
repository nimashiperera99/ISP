import { Link } from 'react-router-dom';
import styled from 'styled-components';
import main from '../assets/main.jpg';
import { useGlobalContext } from '../context/appContext';
import { Redirect } from 'react-router-dom';
import logo from '../assets/logo.png';
import { startTransition } from 'react';
import background from "../assets/back.jpg";
import background1 from "../assets/happy.png";
import Footer from './footer';
import background3 from "../assets/last.png";
function Home() {
  const { user } = useGlobalContext();

  return (
    <>
      {user && <Redirect to='/dashboard' />}
      <Wrapper>
      <img src={background} alt="background" className="pu"/>
      <div class="centered">
      
      {/* <img src={background3} alt="background" className="pu3"/> */}
        
            <h1>MR.FIXIT</h1>
            <p className='my'>
            Analyze suspicious files, domains, IPs and URLs to detect malware and other breaches
            </p>
            <div>
            <Link to='/register' className='btn'>
              Get Started
            </Link>
            </div>
            <br/>
         
            <img src={background1} alt="background" className="pu2"/>
          
          </div>
       
     <Footer/>
      </Wrapper>
    </>
  );
}

const Wrapper = styled.div`
background-image: url(${background});
  nav {
    width: var(--fluid-width);
    max-width: var(--max-width);
    margin: 0 auto;
    height: 6rem;
    display: flex;
    align-items: center;
  }
  h1 {
    font-weight: 700;
    font-size: 4.5rem;
    margin-bottom: 0.5rem;
    color: #FFFFFF;
    text-align: center;
    font-family: 'High Tower Text';
  }
  .centered {
    position: absolute;
    top: 60%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
  .pu {

    background-position: center;

    background-size: cover;
    background-repeat: no-repeat;
    height: 100%;
    width: 100%;
    
 
  }
  .pu3 {

    background-position: center;

    background-size: cover;
    background-repeat: no-repeat;
    height: 10%;
    width: 10%;

    margin-left: 43%;
 
  }
  .pu2 {
  width: 50%;
  height: 100%;
  margin-top: 10px;
  margin-left: 176px;

}

  .main-img {
    display: none;
  }
  @media (min-width: 992px) {
    .container {
      grid-template-columns: 1fr 1fr;
      column-gap: 6rem;
    }
    .main-img {
      display: block;
    }
  }
  .btn {
    text-align: center;
    border: 2px solid #C7C7C7;
    border-radius: 67px;
    color: #21D2E5;
    background-color: black;
    margin-left: 33%;
    font-size: 1.4rem;
    padding: 10px 40px;
    font-family: 'Gotham';

    
   
  
   
  }
 .my{
    font-size: 1.4rem;
    color: #21D2E5;
    font-family: 'Aclonica';
    text-align: center;
  }
`;

export default Home;



