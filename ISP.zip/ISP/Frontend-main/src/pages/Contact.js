import { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useGlobalContext } from '../context/appContext';
import background from '../assets/back.jpg';
import logo from '../assets/logo.png';
import { Link } from 'react-router-dom';
import FormRow from '../components/FormRow';
import Footer from './footer';

function Contact() {
  return (
    <>
 
    <Wrapper className=''>
      
    <img src={background} alt='jobio' className="pu" />
    <div class="centered">
      <div class="row">
        <div class="column">
          <h1><b>Contact <span style={{color:'#00CCFF' }}>Us</span></b></h1><br></br>
          <h4>
            We are very pleased to hear from<br></br> you.
            <br></br>
            detectEvil@info.com
            <br></br><br></br><br></br>
            245/7, Flower Road, Colombo 07,<br></br> Sri Lanka
            <br></br><br></br><br></br>
            +94 715846581
            <br></br>
            +94 112587861
          </h4>
        </div>
        <div class="column">
          <h4 align=''><br></br><br></br><br></br><br></br>
            Please let us know about your <span style={{color:'#00CCFF' }}>feedback</span>
            <br></br><br></br>
            <form>
            <label for="name">Your Name</label>
            <input type="text" id="name" name="name"></input>
            <br></br>
            <label for="email">Your Email</label>
            <input type="text" id="email" name="email"></input>
            <br></br>
            <label for="message">Message</label>
            <input type="text" id="message" name="message"></input>
            <br></br><br></br>
            <div>
            <Link to='/register' className='btn'>
              Submit
            </Link>
            </div>
            <br></br><br></br>
            </form>
          </h4>
        </div>
      </div>
    </div>
    </Wrapper>
    <Footer/>
    </>
  );
}

const Wrapper = styled.section`
background-image: url(${background});

h1 {
  color: #000000;
  font-family: "Aclonica";
}

h4 {
  font-family: "Aclonica";
  font-style: normal;
  font-weight: 400;
  color: #000000;
}
.pu {
  background-position: center;
  background-size: cover;
  background-repeat: no-repeat;
  height: 100%;
  width: 100%;
  

}
* {
  box-sizing: border-box;
}
.centered {
  position: absolute;
  top: 35%;
  width: 90%;
  left: 50%;

  transform: translate(-50%, -50%);
}
.column {
  float: left;
  width: 50%;
  padding: 10px;
  height: 300px;
}

.row:after {
  content: "";
  display: table;
  clear: both;
  
}

input[type=text] {
  width: 100%;
  padding: 8px 16px;
  background-color:transparent;
  margin: 8px 0;
  border: none;

  border-bottom: 2px solid #ffffff;
}
.btn {
  text-align: center;
    border: 2px solid #404040;
    border-radius: 67px;
    color: #ffffff;
    background-color: white;
    
    font-size: 1.4rem;
    font-weight: 700;
    padding: 10px 40px;
    font-family: 'Gotham';
}

`;

export default Contact