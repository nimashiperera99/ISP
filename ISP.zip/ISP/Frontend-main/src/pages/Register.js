import { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useGlobalContext } from '../context/appContext';
import { Redirect } from 'react-router-dom';
import FormRow from '../components/FormRow';
import logos from '../assets/logos.png';
import logo from '../assets/logo.png';import bgimage from '.././assets/bg2.png';
import Footer from './footer';

function Register() {
  const [values, setValues] = useState({
    name: '',
    email: '',
    password: '',
    isMember: true,
  });

  const { user, register, login, isLoading, showAlert } = useGlobalContext();
  const toggleMember = () => {
    setValues({ ...values, isMember: !values.isMember });
  };
  const handleChange = (e) => {
    setValues({ ...values, [e.target.name]: e.target.value });
  };
  const onSubmit = (e) => {
    e.preventDefault();
    const { name, email, password, isMember } = values;

    if (isMember) {
      login({ email, password });
    } else {
      register({ name, email, password });
    }
  };

  return (
    <>
      {user && <Redirect to='/dashboard' />}
      <Wrapper>
        <div className=''>
          {showAlert && (
            <div className='alert alert-danger'>
              there was an error, please try again
            </div>
          )}
          <form className='form' onSubmit={onSubmit}>
            {/* <img src={logo} alt='jobio' className='logo' /> */}
            <div className='title'>{values.isMember ? 'Login' : 'SignUp'}</div>
            {/* name field */}
            {!values.isMember && (
              <FormRow
                type='name'
                name='name'
                placeholder='Enter your name'
                value={values.name}
                handleChange={handleChange}
              />
             
            )}
             <br/>

            {/* single form row */}
            <FormRow
              type='email'
              name='email'
              placeholder='Enter your email'
              value={values.email}
              handleChange={handleChange}
            />
            {/* end of single form row */}
            {/* single form row */}
            <FormRow
              type='password'
              name='password'
              placeholder='Enter your password'
              value={values.password}
              handleChange={handleChange}
            />
            {/* end of single form row */}
            <div className='grid-container'>
            <div className='grid-item'>
            <button
              type='submit'
              className='btn btn-block'
              disabled={isLoading}
            >
              {isLoading ? 'Fetching User...' : 'Submit'}
            </button>
            <p>
              {values.isMember ? 'Not a member yet?' : 'Have Already an Account?'}

              <button
                type='button'
                onClick={toggleMember}
                className='member-btn'
              >
                {values.isMember ? 'SignUp Here' : 'Login Here'}
              </button>
            </p>
                </div>
                <div className='grid-item'>
                <img src={logos} alt='logo' className='logo' /> 
                </div>
           </div>
            
          </form>
        </div>
        <Footer/>
      </Wrapper>
    </>
  );
}

const Wrapper = styled.section`

background-size: cover;


  background:url(${bgimage});
  background-size: cover;
 
  width: 100%;
  height: 130vh;
  background-repeat: no-repeat;
  .logo {
  width: 110%;

  height: 70%;
  border-right: 2px solid #FFFFFF;
  border-bottom: 2px solid #FFFFFF;
  border-left: 2px solid #FFFFFF;

 
 
  }
  .form {
  
    min-height: 850px;
    margin-top:0;
    margin-bottom: 0;
    margin-right: 0;
    font-size: 1.25rem;
    min-width: 660px;
    border-top: 5px solid #21D2E5;
    border-bottom: 5px solid  #21D2E5;
   
  }

  .grid-container{
    display: grid;
    grid-template-columns: auto auto;
  }
 
 FormRow {
    font-size: 1.25rem;
    margin-top: 1rem;
    border: 1px solid #434343;
    border-radius: 40px;
    margin-bottom: 1rem;
  }

  h1 {
    text-align: center;
  }

  .title {
    margin-top: 30px;
    text-align: center;
    margin-bottom: 1.5rem;
    font-size: 60px;
    font-weight: 1000;
   
  }
  p {
    margin: 0;
    margin-top: 20px;
    text-align: center;
  }
  .btn {
    text-align: center;
    border: 2px solid #C7C7C7;
    border-radius: 67px;
    color: #21D2E5;
    margin-top: 20px;
    background-color: black;
    margin-left: 53%;
    font-size: 1.2rem;
    width: 200px;
    padding: 10px 30px;
    font-family: 'Gotham';
    margin-bottom: 20px;
    
  }
  .member-btn {
    background: transparent;
    border: transparent;
    color: #21D2E5;
    cursor: pointer;
  }
`;

export default Register;
