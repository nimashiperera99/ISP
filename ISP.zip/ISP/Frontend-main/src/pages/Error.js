import React from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';


import background from "../assets/back.jpg";
import background1 from "../assets/sad.png";
const Error = () => {
  return (
    <Wrapper>
      
      <div>
      <img src={background} alt="background" className="pu"/>
        {/* <img src={img} alt='not found' /> */}
        <div class="centered">
     
        <h1>4<span style={{color:'#21D2E5' }}>0</span>4</h1>
        <h3> Page <span style={{color:'#21D2E5' }}>Not  </span>Found</h3>
     
        <img src={background1} alt="background1" className="pu1"/>
       <br/>
        <Link to='/' className='btn'>Back to home</Link>
      </div>
      </div>
      
    </Wrapper>
  );
};

const Wrapper = styled.main`
  text-align: center;
 
  display: flex;
 
  justify-content: center;
  h3 {
    margin-bottom: 0.5rem;
  }
  p {
    margin-top: 0;
    margin-bottom: 0.5rem;
    color: var(--grey-500);
  }
  a {
    color: var(--primary-500);
    text-decoration: underline;
  }
  .pu {

    background-position: center;

    background-size: cover;
    background-repeat: no-repeat;
    height: 100%;
    width: 100%;
    
 
  }
  .pu1 {
    width: 50%;
    height: 100%;
  margin-top: 10px;
  }
  .centered {
    position: absolute;
    top: 50%;
    left: 50%;

    transform: translate(-50%, -50%);
  }
  h1 {
    font-size: 10rem;
    color: #FFFFFF;
  }
  h3 {
    font-size: 3rem;
    color: #FFFFFF;
  }
.btn {
  display: inline-block;
margin-left: -28px;
 
  border: 2px solid #21D2E5;
  border-radius: 67px;
  color: #21D2E5;
  padding: 10px 40px;
  background-color: black;
  text-decoration: none;
  transition: all 0.3s ease-out;
}
`;

export default Error;
