import React from 'react'

function Policy() {
  return (
    <div>
      Policy
    </div>
  )
}

export default Policy
