import React from 'react'

function Privacy() {
  return (
    <div>
      Privacy
    </div>
  )
}

export default Privacy
