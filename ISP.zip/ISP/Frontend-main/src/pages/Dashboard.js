import styled from "styled-components";
import { useState, useEffect } from "react";
import { useGlobalContext } from "../context/appContext";
import { request } from "malicious-link-detector";
import FormRow from "../components/FormRow";
import Navbar from "../components/Navbar";
import Jobs from "../components/Jobs";
import background from "../assets/back.jpg";
import logo from "../assets/last.png";
import Footer from "./footer";

// import {util} from 'util';
// import {client} from 'shodan-client';

function Dashboard() {
  const [state, setState] = useState();
  const [values, setValues] = useState({ company: state });
  const [malicious, setMalicious] = useState();
  const handleChange = (e) => {
    setValues({ ...values, [e.target.name]: e.target.value });
  };

  const { isLoading, showAlert, fetchJobs, createJob } = useGlobalContext();

  const handleSubmit = (e) => {
    e.preventDefault();
    const { company } = values;
    if (company) {
      setState(values);
    }
  };

  // console.log(state)
  console.log(values.URL);

  const fetchPWD = () => {
    request(values.URL).then((res) => {
      console.log(res);
      setMalicious(res);
    });
  };

  const check = () => {
    if (malicious === "Safe") {
      return <div className="safe">{malicious}</div>;
    }
    if (malicious === "Dangerous") {
      return <div className="danger">{malicious}</div>;
    }
    if (malicious === "Too many contents") {
      return (
        <div className="content">
          <h1>{malicious}</h1>
          
        </div>
      );
    }
    if (malicious === "Invalid") {
      return <div className="invalid">{malicious}</div>;
    }
    if (malicious === "Suspicious") {
      return <div className="suspicious">{malicious}</div>;
    } else {
      return <div></div>;
    }
  };

  return (
    <>
      <Wrapper>

        <img src={background} alt="background" className="pu" />
        <div className="centered">
         
          <br/>
          <br/>
          <br/>
          <br/>
       
          <h1 className="topic"> DetectEvil</h1>
          <p className="aaa">Please enter URL with protocol specified i.e https://www.SLIIT.LK</p>
   
        <form className="job-form" onSubmit={handleSubmit}>
          {/* position */}
          <FormRow
            type="name"
            name="URL"
            value={values.company}
            handleChange={handleChange}
            horizontal
            placeholder="Enter Your URL"
          />
           <div className="url">
          <u>
            <b>
              <i>{values.URL ? "URL Found" : "No URL Found"}</i>
            </b>
          </u>
        </div>
          <button
            type="SUBMIT"
            className="btn"
            disabled={isLoading}
            onClick={fetchPWD}
          >
            {isLoading ? "Adding New Job..." : "SUBMIT"}
          </button>
          <br />
          <br />
          <h5>Analyze suspicious files, domains, IPs and URLs to detect malware and other breaches</h5>
        </form>
        {check()}
        
        </div>

   
      
      
      </Wrapper>
      <Footer/>
    </>
    
  );
}

const Wrapper = styled.section`
  .pu {
    Width: 100%;
    height: 110%;
    background-position: center;
 
  }
  .topic{
    font-family:High Tower Text;
    font-size:4.4rem;
  }
  .aaa {
    font-size: 1.5rem;
    text-align: center;
    color: #000000;
    text-transform: uppercase;
    letter-spacing: var(--spacing);
    margin-bottom: 2rem;
  }
  .hui {
    width: 100px;
    height: 100px;
  }
  .centered {
    position: absolute;
    top: 50%;
    left: 50%;
    text-align: center;
    transform: translate(-50%, -50%);
    color: white;
  }
  .url {
    padding: 1rem 1rem;
    font-family: system-ui;
    font-size: 1.2rem;
    color: black;
    background: #000000; /* fallback for old browsers */
    background: -webkit-linear-gradient(
      to right,
      #B8C3D4,
      #B8C3ED
    ); /* Chrome 10-25, Safari 5.1-6 */
    background: linear-gradient(
      to right,
      #000000,
      #D0D3DC,
      #D0D3DC,
      #000000

    ); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
    text-align: center;
    border-radius: 20px;
    box-shadow: rgba(50, 50, 93, 0.25) 0px 30px 60px -12px inset,
      rgba(0, 0, 0, 0.3) 0px 18px 36px -18px inset;
    font-family: cursive;
  }
  .safe {
    background: -webkit-linear-gradient(
      to right,
      #99f2c8,
      #1f4037
    ); /* Chrome 10-25, Safari 5.1-6 */
    
    padding: 1rem 1rem;
    font-size: 10rem;
    color: #63FF7B;
    text-align: center;
    border-radius: 20px;
    
    font-family: Times New Roman;
  }
  .danger {
    background: -webkit-linear-gradient(
      to right,
      #ea384d,
      #d31027
    ); /* Chrome 10-25, Safari 5.1-6 */

    padding: 1rem 1rem;
    font-size: 5rem;
    color: #E02E25;
    text-align: center;
    border-radius: 20px;
    font-family: Times New Roman;
  }
  .content {

    font-family: Times New Roman;
    background: -webkit-linear-gradient(
      to right,
      #e1f5c4,
      #0D0D0C
    ); /* Chrome 10-25, Safari 5.1-6 */ 
    padding: 1rem 1rem;
    font-size: 6rem;
    color: #3E7EF7;
    text-align: center;
    border-radius: 20px;
  
    align-item:center;
  }
  .suspicious {
    background: -webkit-linear-gradient(
      to right,
      #240b36,
      #c31432
    ); /* Chrome 10-25, Safari 5.1-6 */
    padding: 1rem 1rem;
    font-size: 5rem;
    color: #F7DE36;
    text-align: center;
    border-radius: 20px;
    font-family: Times New Roman;
  }
  .invalid {
    background: -webkit-linear-gradient(
      to right,
      #E60D0D,
      #070707,
      #E60D0D
    ); /* Chrome 10-25, Safari 5.1-6 */
    padding: 1rem 1rem;
    font-size: 10rem;
    color: #FAEDB1;
    text-align: center;
    border-radius: 20px;
    font-family: Times New Roman;
  }

  .job-form {
  
    .form-input {
      width: 100%;
      padding: 0.75rem;
      border-radius: 20px;
      background-color: #000000;
      color:white;
      Border: 1px solid #050404;
    }

    .form-input:focus {
      outline: 1px solid var(--primary-500);
      border-radius: 20px;
      width: 100%;
      background-color: #8B8B8B;
      color: var(--white);
    }s
    .form-row {
      margin-bottom: 0;
      width: 50%;
      margin: 0 auto;
    

    }
    .btn {
    
      width: 30%;
      Height: 10%;

     
      margin: 0 auto;
      margin-top: 1rem;
      padding: 1.75rem;
  
      border-radius: 20px;
      background-color: #404040;
      color:white;
      font-size: 1.85rem;
    
    
      text-align: center;
      cursor: pointer;
      transition: all 0.3s ease-in-out;
    }
    @media (min-width: 776px) {
      grid-template-columns: 1fr 1fr auto;
      .btn {
        height: 100%;
        padding: 0 2rem;
      }
      column-gap: 2rem;
    }
  }
  .alert {
    max-width: var(--max-width);
    margin-bottom: 1rem;
  }

  .panel-title > a:before {
    float: right !important;
    font-family: FontAwesome;
    content: "\f068";
    padding-right: 5px;
  }
  body {
    background-color: #02025f;
  }
  .panel-title > a.collapsed:before {
    float: right !important;
    content: "\f067";
  }
  .panel-title > a:hover,
  .panel-title > a:active,
  .panel-title > a:focus {
    text-decoration: none;
  }
  .panel-heading {
    padding: 20px 15px;
    border-bottom: 1px solid transparent;
    border-top-right-radius: 3px;
    border-top-left-radius: 3px;
  }
  .panel {
    margin-bottom: 20px !important;
    background-color: #000000;
    border: 1px solid transparent;
    -webkit-box-shadow: 0 1px 1px rgb(0 0 0 / 5%);
    box-shadow: 15px 16px 13px 8px rgb(4 4 4 / 5%);
  }
  .jumbotron {
    padding-top: 30px;
    padding-bottom: 30px;
    margin-bottom: 30px;
    color: inherit;
    background-color: #00bcd4;
    text-align: center;
    color: #000000;
  }
`;

export default Dashboard;
