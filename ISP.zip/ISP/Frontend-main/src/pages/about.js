import { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useGlobalContext } from '../context/appContext';
import background from '../assets/back.jpg';
import logo from '../assets/last.png';
import FormRow from '../components/FormRow';
import Footer from './footer';

function About() {
  return (
    <>
   
  
    <Wrapper className=''>
    <img src={background} alt='jobio' className="pu" />
    <div class="centered">
      <div class="row">
        <div class="column">
          <h1><b>F<span style={{color:'#21D2E5' }}>A</span>Q</b></h1>
          <h4>What does DetectEvil Mean?</h4>
          <h5>Mr.FixIt is a software tool that is used for checking or verifying broken hyperlinks in a website or a Web page. 
            It allows website owners to identify dead or broken links and thus avoid linking to invalid Web pages.</h5> 
          <h4>Security?</h4>
          <h5>Integrated with Google Safe Browsing According to Google, their website checker “examines billions of URLs 
            per day looking for unsafe websites,” which makes this a great website safety-check tool.</h5> 
          <h4>Benefits of using Mr.FiXIt...</h4>
          <h5>One of the important benefits of using a link checker is in ensuring good usability by removing broken 
            links and also in ensuring the search engine optimization of a Web page or a website is not affected.</h5> 
        </div>
        <div class="column">
          <br></br><br></br><br></br>
          <h4>How DetectEvil work?</h4>
          <h5>Mr.FixIt is is a safe link checker which uses advanced artificial intelligence and natural language 
            processing techniques to analyze website link characteristics and check the credibility of the company owning it.</h5>
          <center><img src={logo} alt='jobo' className='logo' /></center>
        </div>
      </div>
    </div>
    <Footer/>
    </Wrapper>
    </>
  );
}

const Wrapper = styled.section`

background-image: url(${background});
h1 {
  color: #00008B;
}

h4 {
  font-family: "Aclonica";
  font-style: normal;
  font-weight: 400;
  color: #00CCFF;
}

.pu {
  background-position: center;
  background-size: cover;
  background-repeat: no-repeat;
  height: 100%;
  width: 100%;
  

}
.centered {
  position: absolute;
  top: 35%;
  width: 90%;
  left: 50%;

  transform: translate(-50%, -50%);
}
h5 {
  font-family: "Aclonica";
  font-style: normal;
  font-weight: 400;
  color: #000000;
}

* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 50%;
  padding: 10px;
  height: 300px;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

input[type=text] {
  width: 100%;
  padding: 8px 16px;
  margin: 8px 0;
  border: none;


}
.logo {
  width: 40%;
  margin-top: 40px;
  height: 40%;
  object-fit: cover;
  border-radius: 50%;
  border: 2px solid #21D2E5;
  padding: 10px;
 
  box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.5);
}


`;

export default About